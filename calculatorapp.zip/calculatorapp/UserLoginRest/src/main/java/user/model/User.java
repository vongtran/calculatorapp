package user.model;

public class User {

	private String status;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String status) {
		super();
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
