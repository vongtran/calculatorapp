import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.styl']
})
export class CalculatorComponent implements OnInit {
  a: number = 0;
  b: number = 0;
  operator: string = "+";
  result: number = 0;
  constructor(private httpClientService: HttpClientService) { }

  ngOnInit(): void {
  }

  calculate() {
    if (this.operator === "+") this.result = this.a + this.b;
    else if (this.operator === "-") this.result = this.a - this.b;
    else if (this.operator === "*") this.result = this.a * this.b;
    else if (this.operator === "/" && this.b !== 0) this.result = this.a / this.b;
    this.httpClientService.logCalculator(this.a + this.operator + this.b + "=" + this.result).subscribe(res => {console.log("Successful log")});
  }

}
