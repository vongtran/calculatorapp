import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { from } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  constructor(private httpClient: HttpClient) { }

  public logCalculator(logString) {
    console.log("logCalculator");
    const headers = new HttpHeaders({Authorization: 'Basic ' + btoa('admin:admin')});
    return this.httpClient.post<String>("http://localhost:8080/logCalculator", logString, {headers});
  }
}